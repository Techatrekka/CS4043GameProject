local composer = require ("composer")
local scene = composer.newScene()

local function gotoGame()
  composer.gotoScene("Level1")
end

function scene:create(event)

local screenGroup = self.view
local background = display.newImageRect("Background.png", 1280, 720)
background.x = display.contentCenterX
background.y = display.contentCenterY
screenGroup:insert(background)

local ULMAP = display.newImageRect("ULMAP.png", 700, 500)
ULMAP.x = display.contentCenterX - 200
ULMAP.y = display.contentCenterY + 110
screenGroup:insert(ULMAP)

local playButton = display.newImageRect("playButton.png", 500, 150)
playButton.x = display.contentCenterX + 250
playButton.y = display.contentCenterY + 40
screenGroup:insert(playButton)
playButton:addEventListener("tap", gotoGame )

local quitButton = display.newImageRect("quitButton.png", 500, 150)
quitButton.x = display.contentCenterX + 250
quitButton.y = display.contentCenterY + 200
screenGroup:insert(quitButton)

local Lepresean = display.newImageRect("Lepresean.png", 200, 250)
Lepresean.x = display.contentCenterX - 275
Lepresean.y = display.contentCenterY - 175
screenGroup:insert(Lepresean)

local Lepresean2 = display.newImageRect("newLabel.png", 700, 500)
Lepresean2.x = display.contentCenterX + 260
Lepresean2.y = display.contentCenterY - 150
screenGroup:insert(Lepresean2)

end

-- show()
function scene:show( event )

	local sceneGroup = self.view
	local phase = event.phase

	if ( phase == "will" ) then
		-- Code here runs when the scene is still off screen (but is about to come on screen)

	elseif ( phase == "did" ) then
		-- Code here runs when the scene is entirely on screen

	end
end


-- hide()
function scene:hide( event )

	local sceneGroup = self.view
	local phase = event.phase

	if ( phase == "will" ) then
		-- Code here runs when the scene is on screen (but is about to go off screen)

	elseif ( phase == "did" ) then
		-- Code here runs immediately after the scene goes entirely off screen

	end
end


-- destroy()
function scene:destroy( event )

	local sceneGroup = self.view
	-- Code here runs prior to the removal of scene's view

end


-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene
