local composer = require ("composer")
math.randomseed( os.time() )
composer.gotoScene( "Menu", { params={ } } )
